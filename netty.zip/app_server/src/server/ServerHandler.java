package server;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import Dao.DAO;

import UDP.RpcRequest;
import UDP.RpcResponse;
 
public class ServerHandler extends ChannelInboundHandlerAdapter{
 
    //����client���͵���Ϣ
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        RpcRequest request = (RpcRequest) msg;
        System.out.println("���յ��ͻ�����Ϣ:" + request.toString());
        System.out.println(request.getHeader());
        if(request.getHeader().equals("add"))
        {
        	//System.out.println("���յ��ͻ�����Ϣ:" + request.toString());
        	new DAO();
            DAO.Insert_API(request.getId(),request.getTime(), request.getSwitch(), 
            		request.getVoltage(), request.getElectron_flow(), request.getBrightness(), request.getColor()); 
            
            //���ص����ݽṹ
            String str1=DAO.get_All();
            
            RpcResponse response = new RpcResponse();
            
            SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
            String timeString = time.format(new Date());     
            response.setTime(timeString);
            
            response.setData(str1);
            response.setStatus(1);
            ctx.writeAndFlush(response);
        }
        else if(request.getHeader().equals("find"))
        {
        	System.out.println(request.getHeader());
        	new DAO();
            String str1=DAO.Find(request.getId());
            
            RpcResponse response = new RpcResponse();
            
            SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
            String timeString = time.format(new Date());     
            response.setTime(timeString);
            
            response.setData(str1);
            response.setStatus(1);
            ctx.writeAndFlush(response);
        
        }
        else if(request.getHeader().equals("alert"))
        {
        	System.out.println(request.toString());
        	new DAO();
        	DAO.Update(request.getId(), request.getSwitch(), request.getBrightness(), request.getColor());
        	
        	//���ص����ݽṹ
            String str1=DAO.get_All();
            
            RpcResponse response = new RpcResponse();
            
            SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
            String timeString = time.format(new Date());     
            response.setTime(timeString);
            
            response.setData(str1);
            response.setStatus(1);
            ctx.writeAndFlush(response);
        }
        else if(request.getHeader().equals("delete")) {
        	new DAO();
        	DAO.Delete(request.getId());
        	
        	//���ص����ݽṹ
            String str1=DAO.get_All();
            
            RpcResponse response = new RpcResponse();
            
            SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
            String timeString = time.format(new Date());     
            response.setTime(timeString);
            
            response.setData(str1);
            response.setStatus(1);
            ctx.writeAndFlush(response);
        }
        else if(request.getHeader().equals("find_all")){
        	new DAO();
        	String str1=DAO.get_All();
            
            RpcResponse response = new RpcResponse();
            
            SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
            String timeString = time.format(new Date());     
            response.setTime(timeString);
            
            response.setData(str1);
            response.setStatus(1);
            ctx.writeAndFlush(response);
        }
        
    }
 
    //֪ͨ����������channelRead()�ǵ�ǰ�������е����һ����Ϣʱ����
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        System.out.println("����˽����������..");
        ctx.flush();
    }
 
    //������ʱ�����쳣ʱ����
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        ctx.close();
    }
 
    //�ͻ���ȥ�ͷ�������ӳɹ�ʱ����
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
   //        ctx.writeAndFlush("hello client");
    }
}
