package main;


import server.Server;

public class Main {
 
    public static void main(String[] args) throws Exception {
        //����server����
        new Server().bind(8080);
    }
    
}

