package Dao;

public class Ligthts {
	
	String time;
    String switch_status;                //����״̬
    int voltage;             //��ѹ
    int electron_flow;       //����
    int brightness;         //����(�ٷֱ�)
    int color;              //��ɫ(�ٷֱ�)
    int id; 				//·�Ʊ��
	
    
    public Ligthts(String t,String s,int v,int e,int b,int c,int id) {
    	
    	this.time=t;
    	this.switch_status=s;
    	this.voltage=v;
    	this.electron_flow=e;
    	this.brightness=b;
    	this.color=c;
    	this.id=id;
    	
    }
    
	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
	
	public String getSwitch() {
		return switch_status;
	}

	public void setSwitch(String switch_status) {
		this.switch_status = switch_status;
	}

	public int getVoltage() {
		return voltage;
	}

	public void setVoltage(int voltage) {
		this.voltage = voltage;
	}

	public int getElectron_flow() {
		return electron_flow;
	}

	public void setElectron_flow(int electron_flow) {
		this.electron_flow = electron_flow;
	}
	
	public void setBrightness(int brightness) {
		this.brightness = brightness;
	}
	
	public int getBrightness() {
		return brightness;
	}
	
	public void setColor(int color) {
		this.color = color;
	}
	
	public int getColor() {
		return color;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}

}
