package Dao;

public class JDBCinit {

	JDBCUtil jdbcUtil = new JDBCUtil("com.mysql.cj.jdbc.Driver", 
			"jdbc:mysql://localhost:3306/test?userUnicode=true&characterEncoding=utf-8&userSSL=false&serverTimezone=GMT", 
								"root", "DYH77557123");
}
