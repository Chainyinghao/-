package Dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAO {
	
	public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver"; 
	public static final String URL = "jdbc:mysql://localhost:3306/test?userUnicode=true&characterEncoding=utf-8&userSSL=false&serverTimezone=GMT"; 
	public static final String USERNAME = "root"; 
	public static final String PASSWORD = "DYH77557123"; 
	private static Connection conn;
	
	/*JDBCUtil jdbcUtil = new JDBCUtil("com.mysql.cj.jdbc.Driver", 
			"jdbc:mysql://localhost:3306/test?userUnicode=true&characterEncoding=utf-8&userSSL=false&serverTimezone=GMT", 
								"root", "DYH77557123");*/
	
	
	public static void ConnDatabase() throws Exception {
		

		Class.forName(DRIVER_CLASS);
		conn=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		
	}
	
	public static void Close() throws SQLException {
		
		conn.close();
	}
	public static void Insert_API(int id,String time,String status,int v,int i,int br,int color) throws Exception {
		
		ConnDatabase();
		String sqlString="{CALL insert_values("+id+","+"'"+time+"'"+","+"'"+status+"'"+","+v+","+i+","+br+","+color+")}";  //���ô洢����
		//jdbcUtil.executeUpdate(sqlString, null);
		//String sqlString="insert into lights_info(ʱ��,����״̬,��ѹ,����,����,��ɫ) values (\"2019-04-30 20:47:00\",\"on\",220,2,50,50)";
		//System.out.println(jdbcUtil.executeUpdate(sqlString, null));
		CallableStatement cstm = conn.prepareCall(sqlString); //ʵ��������cstm 
		cstm.execute();
		cstm.close();
		Close();
	}
	
	public static String get_All() throws Exception {
		ConnDatabase();
		String str="";
		String sqlString="select * from lights_info";
		try {
			PreparedStatement pStatement=conn.prepareStatement(sqlString);
			ResultSet rSet=pStatement.executeQuery();
			while(rSet.next()) {
				str +=rSet.getString(1)+"\t"+rSet.getString(2)+"\t"+rSet.getString(3)+"\t"+rSet.getString(4)+"\t"+
			rSet.getString(5)+"\t"+rSet.getString(6)+"\t"+rSet.getString(7)+"\n";	
			}
			rSet.close();
			pStatement.close();
			return str;
		} catch (Exception e) {
			// TODO: handle exception
			return "";
		}	
		
			
	}
	
	public static void Update(int id,String status,int b,int c) throws Exception {
		ConnDatabase();
		String sqlString="update lights_info set ����״̬=?,����=?,��ɫ=? where id=?";
		try {
			PreparedStatement pStatement=conn.prepareStatement(sqlString);
			pStatement.setString(1, status);
			pStatement.setInt(2, b);
			pStatement.setInt(3, c);
			pStatement.setInt(4, id);
			pStatement.execute();
			
			pStatement.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String Find(int id) throws Exception {
		ConnDatabase();
		String str="";
		String sqlString="select * from lights_info where id="+id;
		try {
			PreparedStatement pStatement=conn.prepareStatement(sqlString);
			ResultSet rSet=pStatement.executeQuery();
			while(rSet.next()) {
				str +=rSet.getString(1)+"\t"+rSet.getString(2)+"\t"+rSet.getString(3)+"\t"+rSet.getString(4)+"\t"+
			rSet.getString(5)+"\t"+rSet.getString(6)+"\t"+rSet.getString(7)+"\n";	
			}
			rSet.close();
			pStatement.close();
			return str;
		} catch (Exception e) {
			// TODO: handle exception
			return "";
		}	
	}
	
	public static void Delete(int id) throws Exception {
		ConnDatabase();
		try {
			String sqlString="delete from lights_info where id =?";
			PreparedStatement pStatement=conn.prepareStatement(sqlString);
			pStatement.setInt(1, id);
			pStatement.executeUpdate();
			pStatement.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
