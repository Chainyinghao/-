package UDP;


public class RpcResponse {
	
	String time; // new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
	private Object data;
	int status;
	
    public String getTime() {
        return time;
    }
 
    public void setTime(String time) {
        this.time = time;
    }
 
    public Object getData() {
        return data;
    }
 
    public void setData(Object data) {
        this.data = data;
    }
    public int getStatus() {
        return status;
    }
 
    public void setStatus(int status) {
        this.status = status;
    }
 
    @Override
    public String toString() {
        return "time:'" + time + '\'' + ", data=" + data + ", status=" + status;
    }

}
