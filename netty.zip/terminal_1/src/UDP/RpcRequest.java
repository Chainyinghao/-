package UDP;


public class RpcRequest {
	
	//SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
	String header;
	String time;
    String switch_status;                //����״̬
    int voltage;             //��ѹ
    int electron_flow;       //����
    int brightness;         //����(�ٷֱ�)
    int color;              //��ɫ(�ٷֱ�)
    int id; 				//·�Ʊ��
	
    public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}
    
	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
	public String getSwitch() {
		return switch_status;
	}

	public void setSwitch(String switch_status) {
		this.switch_status = switch_status;
	}

	public int getVoltage() {
		return voltage;
	}

	public void setVoltage(int voltage) {
		this.voltage = voltage;
	}

	public int getElectron_flow() {
		return electron_flow;
	}

	public void setElectron_flow(int electron_flow) {
		this.electron_flow = electron_flow;
	}
	
	public void setBrightness(int brightness) {
		this.brightness = brightness;
	}
	
	public int getBrightness() {
		return brightness;
	}
	
	public void setColor(int color) {
		this.color = color;
	}
	
	public int getColor() {
		return color;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	
	@Override
	public String toString() {
		return "���:"+id+"ʱ��:" + time + "  ��ѹ(V):" + voltage + " ����(A):" 
	            + electron_flow + " ����(%):"+brightness +" ��ɫ(%):"+ color +" ����״̬:" + switch_status;
	}


}
