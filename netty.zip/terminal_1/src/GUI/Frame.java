package GUI;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.Printable;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;

import UDP.RpcRequest;
import client.Client;
import io.netty.channel.Channel;


class Frame extends JFrame implements ActionListener   {
	
	public static int v=0;
	public static int i=0;

	
	final JTextArea textArea = new JTextArea("���\t    ʱ��\t\t����״̬\t��ѹ(V)\t����(mA)\t����(%)\t��ɫ(%)\n",10,7);
	final JTextField TextField1=new JTextField();
	final JTextField TextField2=new JTextField();
	final JTextField TextField3=new JTextField();
	final JTextField TextField4=new JTextField();
	final JTextField TextField5=new JTextField();
	final JTextField TextField6=new JTextField();
	final JTextField TextField7=new JTextField();

	
	Frame() throws Exception {
	
		this.setResizable(false);   //���ɱ�����
		
		Font f=new Font("����",Font.BOLD, 12);
		 /************************����*********************/
		setTitle("·�ƹ���ϵͳ");
		setVisible(true);
		getContentPane().setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 452);
		/************************��ʾ��Ϣ���*********************/
		final JLabel title = new JLabel("·����Ϣ");
		title.setFont(f);
		title.setBounds(20, 177, 60, 15);
		getContentPane().add(title);
		
		final JScrollPane jscrollPane = new JScrollPane(textArea);
		jscrollPane.setBounds(20, 209, 647, 194);
		jscrollPane.setHorizontalScrollBarPolicy(30);
		//jscrollPane.setWheelScrollingEnabled(true);
		getContentPane().add(jscrollPane);

		/************************������Ϣ���*********************/
		final JPanel inputPanel = new JPanel(new GridLayout(2,7,5,5));
		final JLabel Title1 = new JLabel("���",SwingConstants.CENTER);
		final JLabel Title2 = new JLabel("ʱ��",SwingConstants.CENTER);
		final JLabel Title4 = new JLabel("����",SwingConstants.CENTER);
		
		inputPanel.add(Title1);
		inputPanel.add(Title2);
		final JLabel Title3 = new JLabel("����״̬",SwingConstants.CENTER);
		inputPanel.add(Title3);
		final JLabel Title5 = new JLabel("��ѹ",SwingConstants.CENTER);
		inputPanel.add(Title5);
		inputPanel.add(Title4);
		final JLabel Title6 = new JLabel("����",SwingConstants.CENTER);
		inputPanel.add(Title6);
		final JLabel Title7 = new JLabel("��ɫ",SwingConstants.CENTER);
		inputPanel.add(Title7);
		inputPanel.add(TextField1);
		TextField1.setHorizontalAlignment(SwingConstants.CENTER);
		TextField2.setEditable(false);
		TextField2.setHorizontalAlignment(SwingConstants.CENTER);
		inputPanel.add(TextField2);
		TextField3.setHorizontalAlignment(SwingConstants.CENTER);
		inputPanel.add(TextField3);
		TextField4.setEditable(false);
		TextField4.setHorizontalAlignment(SwingConstants.CENTER);
		inputPanel.add(TextField4);
		TextField5.setEditable(false);
		TextField5.setHorizontalAlignment(SwingConstants.CENTER);
		inputPanel.add(TextField5);
		TextField6.setHorizontalAlignment(SwingConstants.CENTER);
		inputPanel.add(TextField6);
		TextField7.setHorizontalAlignment(SwingConstants.CENTER);
		inputPanel.add(TextField7);
		inputPanel.setBounds(20, 20, 647, 64);
		getContentPane().add(inputPanel);

		/************************���ܰ�ť���*********************/
		final JPanel buttonPanel = new JPanel();
		final GridLayout gridLayout = new GridLayout(1,5,4,4);
		buttonPanel.setLayout(gridLayout);
		String[] b = {"��ѯ����","����", "�޸�","����", "ɾ��"};
		JButton[] button = new JButton[5];
		for (int i=0; i<5; i++)
		{
			button[i] = new JButton(b[i]);
			button[i].setFont(new  java.awt.Font("�����п�",  2,  10));
			buttonPanel.add(button[i]);
			button[i].addActionListener(this);
			
		}
		buttonPanel.setBounds(267, 117, 400, 20);
		getContentPane().add(buttonPanel);
		
		setResizable(false);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String op=e.getActionCommand();
		
		switch(op)
	    {
		
		case"��ѯ����":{
			Client client = new Client("127.0.0.1", 8080);  //����UDP����
		       
	        try {
				client.start();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}       //����client����
	        Channel channel = client.getChannel();
	        RpcRequest request = new RpcRequest();   //��Ϣ��
	        request.setHeader("find_all");
	        
	        SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
	        String s2= time.format(new Date());   
	        request.setTime(s2);
	        channel.writeAndFlush(request);
	        String string1 = null;
	        try {
	    		   TimeUnit.SECONDS.sleep(1);
					string1=readFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        
	        textArea.setText("���\tʱ��\t\t����״̬\t��ѹ(V)\t����(mA)\t����(%)\t��ɫ(%)\n"+string1);
	        
		}break;
		
		case"����":{
			int s1 = Integer.parseInt(TextField1.getText());
			String s3 = TextField3.getText();
			int s6 = Integer.parseInt(TextField6.getText());
			int s7 =  Integer.parseInt(TextField7.getText());
			
			SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
	        String s2= time.format(new Date());       
	        Client client = new Client("127.0.0.1", 8080);  //����UDP����
	       
	        try {
				client.start();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}       //����client����
	        Channel channel = client.getChannel();
	        RpcRequest request = new RpcRequest();   //��Ϣ��    
	        request.setHeader("add");
	        request.setId(s1);
	        request.setTime(s2);
	        request.setSwitch(s3);
	        request.setVoltage(getVolt());
	        request.setElectron_flow(getElec());
	        request.setBrightness(s6);
	        request.setColor(s7);
	       
	        channel.writeAndFlush(request);
	        String string1 = null;
	        try {
	    		   TimeUnit.SECONDS.sleep(1);
					string1=readFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}    
	        textArea.setText("���\tʱ��\t\t����״̬\t��ѹ(V)\t����(mA)\t����(%)\t��ɫ(%)\n"+string1);
		}break;		
		case"�޸�":{
			int s1 = Integer.parseInt(TextField1.getText());
			String s3 = TextField3.getText();
			int s6 = Integer.parseInt(TextField6.getText());
			int s7 =  Integer.parseInt(TextField7.getText());
			
			SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
	        String s2= time.format(new Date());   
	        
	        Client client = new Client("127.0.0.1", 8080);  //����UDP����
	        try {
				client.start();
			} catch (Exception e1) {
				// TODO Auto-generated catch block     
				e1.printStackTrace();
			}       //����client����
	        Channel channel = client.getChannel();
	        RpcRequest request = new RpcRequest();   //��Ϣ��
	        
	        request.setHeader("alert");
	        request.setId(s1);
	        request.setTime(s2);
	        request.setSwitch(s3);
	        request.setBrightness(s6);
	        request.setColor(s7);
	        channel.writeAndFlush(request);
	        
	        String string1 = null;
	        
	        try {
	    		   TimeUnit.SECONDS.sleep(1);
					string1=readFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        
	        textArea.setText("���\tʱ��\t\t����״̬\t��ѹ(V)\t����(mA)\t����(%)\t��ɫ(%)\n"+string1);
	        
		}break;
		case"����":{
			
			int s1 = Integer.parseInt(TextField1.getText());
			SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
	        String s2= time.format(new Date());   
	        
	        Client client = new Client("127.0.0.1", 8080);  //����UDP����
	       
	        try {
				client.start();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}       //����client����
	        Channel channel = client.getChannel();
	        RpcRequest request = new RpcRequest();   //��Ϣ��
	        
	        request.setHeader("find");
	        request.setId(s1);
	        request.setTime(s2);
	        channel.writeAndFlush(request);
	        
	        String string1 = null;
	        try {
	    		   TimeUnit.SECONDS.sleep(1);
					string1=readFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		       
	        textArea.setText("���\tʱ��\t\t����״̬\t��ѹ(V)\t����(mA)\t����(%)\t��ɫ(%)\n"+string1);		
		}break;
		
		case"ɾ��":{
			int s1 = Integer.parseInt(TextField1.getText());
			SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //��ȡ��ǰʱ��
	        String s2= time.format(new Date());   
	        
	        Client client = new Client("127.0.0.1", 8080);  //����UDP����
	       
	        try {
				client.start();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}       //����client����
	        Channel channel = client.getChannel();
	        RpcRequest request = new RpcRequest();   //��Ϣ��
	        
	        request.setHeader("delete");
	        request.setId(s1);
	        request.setTime(s2);
	        channel.writeAndFlush(request);
	        
	        String string1 = null;
	        try {
	    		   TimeUnit.SECONDS.sleep(1);
					string1=readFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        
	        textArea.setText("���\tʱ��\t\t����״̬\t��ѹ(V)\t����(mA)\t����(%)\t��ɫ(%)\n"+string1);		
		}break;
		
	  }
		TextField1.setText("");
		TextField3.setText("");
		TextField6.setText("");
		TextField7.setText("");
	}
	
	//������ɵ�ѹ
    public static int getVolt() {
    	Random rand=new Random();
    	v = rand.nextInt(4)+218;	
    	return v;
    }
   //������ɵ���
    public static int getElec() {
    	Random rand=new Random();
    	i = rand.nextInt(4)+28;	
    	return i;
    }
    
    public static String readFile() throws IOException {
    	try {
    		File file=new File("D:\\java_pro\\temp.txt");
			StringBuilder result= new StringBuilder();
			BufferedReader br = new BufferedReader(new FileReader(file));
		
			String s1 = "";
			while((s1=br.readLine())!=null){
				result.append(System.lineSeparator()+s1);
				
			}
			br.close();
			return result.toString();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
    }
	
	public static void main(String[] args)throws Exception {
		new Frame();
		
	}
}
