package client;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;

import UDP.RpcResponse;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.unix.Buffer;
 
public class ClientHandler extends SimpleChannelInboundHandler<RpcResponse>{
 
	private static String tempdate;
    //��������˷��ص�����
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, RpcResponse response) throws Exception {

    	File file =  new File("D:\\java_pro\\temp.txt");
    	file.createNewFile();
    	BufferedWriter out = new BufferedWriter(new FileWriter(file));
    	out.write(response.getData().toString());
    	out.flush();
    	out.close();
    	tempdate=response.getData().toString();
    		
        System.out.println("���ܵ�server��Ӧ����: " + response.toString());
    }
 
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        super.channelActive(ctx);
    }
 
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        ctx.close();
    }
 
    public String getTString() {
    	return tempdate;
    }
}
