package client;

import UDP.RpcDecoder;
import UDP.RpcEncoder;
import UDP.RpcRequest;
import UDP.RpcResponse;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
 
public class Client {
 
    private final String host;
    private final int port;
    private Channel channel;
 
    //���ӷ���˵Ķ˿ںŵ�ַ�Ͷ˿ں�
    public Client(String host, int port) {
        this.host = host;
        this.port = port;
    }
 
    public void start() throws Exception {
        final EventLoopGroup group = new NioEventLoopGroup();
 
        Bootstrap b = new Bootstrap();
        b.group(group).channel(NioSocketChannel.class)  // ʹ��NioSocketChannel����Ϊ�����õ�channel��
            .handler(new ChannelInitializer<SocketChannel>() { // �����ӳ�ʼ����
                @Override
                public void initChannel(SocketChannel ch) throws Exception {
                    System.out.println("����������...");
                    ChannelPipeline pipeline = ch.pipeline();
                    pipeline.addLast(new RpcEncoder(RpcRequest.class)); //����request
                    pipeline.addLast(new RpcDecoder(RpcResponse.class)); //����response
                    pipeline.addLast(new ClientHandler()); //�ͻ��˴�����
 
                }
            });
        //�����첽�������󣬰����Ӷ˿ں�host��Ϣ
        final ChannelFuture future = b.connect(host, port).sync();
 
        future.addListener(new ChannelFutureListener() {
 
            @Override
            public void operationComplete(ChannelFuture arg0) throws Exception {
                if (future.isSuccess()) {
                    System.out.println("���ӷ������ɹ�");
 
                } else {
                    System.out.println("���ӷ�����ʧ��");
                    future.cause().printStackTrace();
                    group.shutdownGracefully(); //�ر��߳���
                }
            }
        });
 
        this.channel = future.channel();
    }
 
    public Channel getChannel() {
        return channel;
    }
}

