#include<unistd.h>
#include<stdio.h>
#include<sys/syscall.h>

#define myfunction 666


int main()
{
	int i;
	printf("Input your number:");
	scanf("%d",&i);
	long j=syscall(666,i);
	int z =i*i*i;
	if(z==j)
	{
		printf("successful: %d\n",j);
	}
	else
		printf("fail");

	return 1;
}
