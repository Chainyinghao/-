#include "Node.h"
class line_Queue
{
protected:
	Node *front, *rear;
public:
	line_Queue();
	void EntQueue(PCB e); //����
	PCB DelQueue();   //����
	bool IsEmpty();   //�п�
	void Traverse();  //����
	void SortQueue();  //����
	void Set_PCB_Pri(int p);  //�������ȼ�
	void Set_PCB_Runt(int rt); //����Ҫ������ʱ��
	void Set_PCB_Sta(char st);  //����PCB״̬
	char Get_PCB_Sta();   //��ȡPCB״̬
	int Get_PCB_Pri();  //��ȡ���ȼ�
	int Get_PCB_Runt();//��ȡ����ʱ��
};
line_Queue::line_Queue()
{
	rear = front = new Node;
}
void line_Queue::EntQueue(PCB e)
{
	Node *p = new Node(e, NULL);
	if (IsEmpty())
	{
		front->next = p;
		rear = p;
	}
	else
	{
		rear->next = p;
		rear = p;
	}

}
PCB line_Queue::DelQueue()
{
	PCB temp;
	if (!IsEmpty())
	{
		Node *p = front->next;
		temp = front->next->a;
		front->next = p->next;
		if (rear == p)
			rear = front;
		delete p;
	}
	return temp;

}
bool line_Queue::IsEmpty()
{
	if (front==rear)
		return true;
	else
		return false;
}
void line_Queue::Traverse()
{
	for (Node *p = front->next; p != NULL; p = p->next)
		p->ShowNode();
}
void line_Queue::SortQueue()
{
	Node *p;
	PCB temp;
	int flag;
	while (true)
	{
		flag = 0;
		for (p = front->next; p->next != 0; p = p->next)
		{
			if (p->a.getPriority() < p->next->a.getPriority())
			{
				temp = p->a;
				p->a = p->next->a;
				p->next->a = temp;
				flag = 1;
			}
		}
		if (flag == 0)
			break;
	}
}
void line_Queue::Set_PCB_Pri(int p)
{
	front->next->a.setPriority(p);
}
void line_Queue::Set_PCB_Runt(int rt)
{
	front->next->a.setRunTime(rt);
}
void line_Queue::Set_PCB_Sta(char st)
{
	front->next->a.setStatus(st);
}
char line_Queue::Get_PCB_Sta()
{
	return front->next->a.getStatus();
}
int line_Queue::Get_PCB_Pri()
{
	return front->next->a.getPriority();
}
int line_Queue::Get_PCB_Runt()
{
	return front->next->a.getRunTime();
}


int main(){
	
	PCB P[5] = { PCB("P1",0,2,3,'R'),PCB("P2",6,3,5,'R'),PCB("P3",4,1,3,'R'),PCB("P4",6,2,4,'R'),PCB("P5",8,4,4,'R') };
	line_Queue Queue1,Queue2;
	for (int i = 0; i < 5; i++)
		Queue1.EntQueue(P[i]);
	Queue1.SortQueue();
	Queue1.Traverse();
	cout << endl;
	while (!Queue1.IsEmpty())
	{
		int pri = Queue1.Get_PCB_Pri();
		int run_time = Queue1.Get_PCB_Runt();
		char status = Queue1.Get_PCB_Sta();
		if (run_time == 0)
		{
			Queue1.Set_PCB_Sta('E');
			PCB temp = Queue1.DelQueue();
			Queue2.EntQueue(temp);
			continue;
		}
		if (run_time > 0 || status != 'E')
		{
			run_time--;
			pri--;
			Queue1.Set_PCB_Pri(pri);
			Queue1.Set_PCB_Runt(run_time);
		}
		if (run_time == 0)
		{
			Queue1.Set_PCB_Sta('E');
			PCB temp = Queue1.DelQueue();
			Queue2.EntQueue(temp);
		}
		Queue1.Traverse();
		Queue2.Traverse();
		cout << endl;
		Queue1.SortQueue();
	}
	return 0;
} 