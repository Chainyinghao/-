#pragma once
#include<iostream>
using namespace std;
class pageTable {

private:
	int pageNum;
	int flag;
	int blockNum;
	int location;
public:
	pageTable() {}
	pageTable(int pn, int ff, int bn, int ll) {
		this->pageNum = pn;
		this->flag = ff;
		this->blockNum = bn;
		this->location = ll;
	}
	int getPageNum() {
		return pageNum;
	}
	int getFlag() {
		return flag;
	}
	int getBlockNum() {
		return blockNum;
	}
	int getLocation() {
		return location;
	}
	void setPageNum(int pn) {
		this->pageNum = pn;
	}
	void setFlag(int ff) {
		this->flag = ff;
	}
	void setBlockNum(int bn) {
		this->blockNum = bn;
	}
	void setLocation(int ll) {
		this->location = ll;
	}
	~pageTable() {}
	
};