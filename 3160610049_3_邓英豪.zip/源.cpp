#include<iostream>
#include<windows.h>
#include<queue>
#include"Node.h"
using namespace std;
class LinkList1 {
private:
	Node *first;
	Node *rear;
public:
	LinkList1() {
		first = new Node;
		first->Next(NULL);
		rear = first;
	}
	LinkList1(pageTable pt[], int n)
	{
		first = new Node;
		rear = first;
		for (int i = 0; i < n; i++)
		{
			Node *s = new Node;
			s->Data2(pt[i]);
			rear->Next(s);
			rear = s;
		}
		rear->Next(NULL);
	}
	void Instead(pageTable temp);
	~LinkList1() {

	}
	void Display();
};
void LinkList1::Display() {
	Node *p = first->next;
	while (p != NULL) {
		p->ShowPageTable();
		p = p->next;
	}
}
void LinkList1::Instead(pageTable temp)
{
	Node *p = first->next;
	while (p->next != NULL)
		p = p->next;
	rear = p;
	Node *s = new Node;
	s->Data2(temp);
	rear->Next(s);
	first->next = first->next->next;

}
class LinkList2 {
private:
	Node *first;
	Node *rear;
public:
	LinkList2() {
		first = new Node;
		first->Next(NULL);
		rear = first;
	}
	LinkList2(Instruct ins[], int n) {
		first = new Node;
		rear = first;
		for (int i = 0; i < n; i++) {
			Node *s = new Node;
			s->Data1(ins[i]);
			rear->Next(s);
			rear = s;
		}
	}
	~LinkList2() {

	}
};

int main() {

	pageTable pt1[7];
	pt1[0] = pageTable(0, 1, 0, 10);
	pt1[1] = pageTable(1, 1, 1, 11);
	pt1[2] = pageTable(2, 1, 2, 12);
	pt1[3] = pageTable(3, 1, 3, 13);
	pt1[4] = pageTable(4, 0, -1, 14);
	pt1[5] = pageTable(5, 0, -1, 15);
	pt1[6] = pageTable(6, 0, -1, 16);
	LinkList1 line1(pt1, 4); //�����е�ҳ��
	cout << "����ҳ����" << endl;
	line1.Display();
	system("pause");
	system("cls");

	Instruct ins[12];   //����10��ָ��
	ins[0] = Instruct("+", 0, 70); //��ָ��Ϊ1������Ϊ0
	ins[1] = Instruct("+", 1, 50);
	ins[2] = Instruct("��", 2, 15);
	ins[3] = Instruct("��", 3, 21);
	ins[4] = Instruct("��λ", 0, 56);
	ins[5] = Instruct("+", 6, 40);
	ins[6] = Instruct("��", 1, 37);
	ins[7] = Instruct("ȡ", 5, 23);
	ins[8] = Instruct("-", 2, 78);
	ins[9] = Instruct("-", 2, 20);
	ins[10] = Instruct("+", 4, 11);
	ins[11] = Instruct("-", 6, 22);
	LinkList2 line2(ins, 12);//�����е�ָ��
	queue<int>q1;//�����ѷ�������ҳ���ҳ�������ʼ��
	for (int i = 0; i < 4; i++)
		q1.push(pt1[i].getBlockNum());

	for (int i = 0; i < 12; i++)
	{
		int page = ins[i].getPageNum();
		if (pt1[page].getFlag() == 1)
		{
			int l = pt1[page].getBlockNum() * 128 + ins[i].getUnitNum();
			cout << "��ָ���ַΪ��" << l << endl;
		}
		else  //�����ж�
		{
			cout << "*��" << page<<"ҳ"<<endl;
			int k = q1.front();   //����Ҫ�滻��ҳ��
			pt1[k].setFlag(0);  //���滻��ҳ�����Ϊ0
			pt1[k].setBlockNum(-1);//��ҳ��ҳ���Ϊ-1
			q1.pop();
			q1.push(page);
			pt1[page].setBlockNum(k);
			pt1[page].setFlag(1);
			line1.Instead(pt1[page]);
		}
		ins[i].Show();
	}
	system("pause");
	system("cls");
	line1.Display();

	
	return 0;
}