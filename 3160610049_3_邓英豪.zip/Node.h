#pragma once
#include<iostream>
#include "Instruct.h"
#include "pageTable.h"
using namespace std;
class Node {
private:
	Instruct data1;
	pageTable data2;	
public:
	Node *next;
	void Data1(Instruct d1) { data1 = d1; }
	void Data2(pageTable d2) { data2 = d2; }
	Instruct Data1() { return data1; }
	pageTable Data2() { return data2; }
	void Next(Node *p) {
		next = p;
	}
	void ShowPageTable() {
		cout << "ҳ�ţ�" << data2.getPageNum() << "\t��־λ��" << data2.getFlag() << "\t��ţ�" 
			<< data2.getBlockNum() << "\t���̵�ַ��" << data2.getLocation() << endl;
	}
};