#pragma once
#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
class Instruct {
	
private:
	string action;
	int pageNum;
	int unitNum;
public:
	Instruct() {}
	Instruct(string ac, int pn, int un) {
		this->action = ac;
		this->pageNum = pn;
		this->unitNum = un;
	}
	string getAction() {
		return action;
	}
	int getPageNum() {
		return pageNum;
	}
	int getUnitNum() {
		return unitNum;
	}
	void setAction(char aa) {
		this->action = aa;
	}
	void setPageNum(int pn) {
		this->pageNum = pn;
	}
	void setUnitNum(int un) {
		this->unitNum = un;
	}
	void Show() {
		cout << "ָ����Ϣ��������" << getAction() << setw(20)<< "ҳ�ţ�" << getPageNum() << setw(20) 
			<< "ƫ�Ƶ�ַ��" << getUnitNum() << endl ;
		cout << endl;
	}
};