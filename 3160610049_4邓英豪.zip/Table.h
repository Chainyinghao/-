#pragma once
#include<iostream>
#include<string>
using namespace std;

class Table {
private:
	string ProcessName;
	int CylinderNum;
	int TrackNum;
	int Recorder;
	string Director;
public:
	Table() {}
	Table(string pn, int cn, int t, int r,string d) {
		this->ProcessName = pn;
		this->CylinderNum = cn;
		this->TrackNum = t;
		this->Recorder = r;
		this->Director = d;
	}

	void setProcessName(string pn) {
		this->ProcessName = pn;
	}
	string getProcessName() {
		return ProcessName;

	}
	void setCylinderNum(int c) {
		this->CylinderNum = c;
	}
	int getCylinder() {
		return CylinderNum;
	}
	void setTrackNum(int t) {
		this->TrackNum = t;
	}
	int getTrackNum() {
		return TrackNum;
	}
	void setRecorder(int r) {
		this->Recorder = r;
	}
	int getRecorder() {
		return Recorder;

	}
	void setDire(string d) {
		this->Director = d;
	}
	string getDire() {
		return Director;
	}
};