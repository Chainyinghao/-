#include<iostream>
#include<Windows.h>
#include<ctime>
#include"Node.h"
#include"Table.h"
using namespace std;


class Link_Table {
private:
	Node *first;
	Node *rear;
public:
	Link_Table() {
		first = new Node;
		first->Next(NULL);
		rear = first;
	}
	Link_Table(Table table[], int n) {
		first = new Node;
		rear = first;
		for (int i = 0; i < n; i++) 
		{
			cout << "����I/O��" << endl;
			Node *temp = new Node;
			temp->Data(table[i],0);
			rear->Next(temp);
			rear = temp;
			Show();
		}
		rear->Next(NULL);
	}
	void Show() {
		Node *p = first->next;
		while (p != NULL) {
			p->Show1();
			p->Show2();
			p = p->next;
		}
	}
	void Show_Table() {
		Node *p=first->next;
		while (p != NULL && !IsFull() && !IsEmpty()) 
		{
			p->Show1();
			p->Show2();
			p = p->next;
		}
	}
	bool Cylinder(int f) //���
	{
		Node *p = first->next;
		while (p != NULL) {
			if (p->getFlag() == 0 && p->getData().getCylinder() == f)
				return true;
			p = p->next;
		}
		return false;
	}
	int Cylinder1(int f) //����
	{
		Node *p = first->next;
		while (p != NULL) {
			if (p->getFlag() == 0 && p->getData().getCylinder() > f)
				return p->getData().getCylinder();
			p = p->next;
		}
		return 0;
	}
	int Cylinder2(int f) //С��
	{
		Node *p = first->next;
		while (p != NULL) {
			if (p->getFlag() == 0 && p->getData().getCylinder() < f)
				return p->getData().getCylinder();
			p = p->next;
		}
		return 0;
	}
	string MinTrack(int f) {
		Node *p = first->next;
		int min = abs(f-p->getData().getTrackNum());
		while (p->next != NULL) {
			if ((p->getFlag() == 0) && (abs(p->getData().getTrackNum() - f) < min))
				min = abs(f - p->getData().getTrackNum());
			p = p->next;
		}
		Node *q = first->next;
		while ((q->getFlag() == 0) && (abs(q->getData().getTrackNum() - f) != min))
			q = q->next;
		q->Show2();
		q->setFlag(1);
		return q->getData().getDire();
	}
	int MinClinder(int c)  //����С����
	{
		Node *p = first->next;
		int min = c;
		while (p->next != NULL)
		{
			if (p->getFlag() == 0 && p->getData().getCylinder() < min)
				min = p->getData().getCylinder();
			p = p->next;
		}
		Node *q = first->next;
		while (q->next!=0)
		{
			if ((q->getData().getCylinder() == min && q->getFlag() == 0))
				break;
			q = q->next;
		}
		q->Show2();
		q->setFlag(1);
		return min;
	} 
	int MaxClinder(int c)  //���������
	{
		Node *p = first->next;
		int max = c;
		while (p->next != NULL)
		{
			if (p->getFlag() == 0 && p->getData().getCylinder() > max)
				max = p->getData().getCylinder();
			p = p->next;
		}
		Node *q = first->next;
		while (q->next != 0)
		{
			if ((q->getData().getCylinder() != max && q->getFlag() == 0))
				break;
			q = q->next;
		}
		q->Show2();
		q->setFlag(1);
		return max;
	}
	bool IsFull()    //�ж϶����Ƿ�����
	{
		Node *p = first->next;
		while (p != NULL)
		{
			if (p->getFlag() == 0)
				return false;
			p = p->next;

		}
		return true;
	}   
	bool IsEmpty()   //�ж��Ƿ��
	{
		if (first == rear)
			return true;
		return false;
	}
};

int main() 
{
	Table A[5];
	Link_Table C;
	int c_flag=0,t_flag=0;
	string dir = "up";
	char ch = 'Y';
	float u_flag;
	while (1)
	{
		cout << "����ѡ��0-1��:";
		cin >> u_flag;

		if (u_flag >= 0.5)
		{
			//��������
			while (!C.IsFull())
			{
				if (!C.IsEmpty())
				{
					if (C.Cylinder(c_flag) == true)   //������ͬ
					{
						dir = C.MinTrack(t_flag);//��С���ҷ��ʽ������ʶ�ѱ�����

					}
					else
					{
						int t1 = C.Cylinder1(c_flag);
						int t2 = C.Cylinder2(c_flag);
						if (dir == "up")
						{

							if (t1 != 0)
								c_flag = C.MinClinder(t1);
							else
							{
								dir = "down";
								c_flag = C.MaxClinder(t2);
							}
						}
						else
						{
							if (t2 != 0)
							{
								dir = "up";
								c_flag = C.MinClinder(t1);
							}
							else
							{
								c_flag = C.MaxClinder(t2);
							}
						}
					}
				}
				else
				{
					cout << "�������Ϊ��" << endl;
					break;
				}
			}
		}
		else   //�����С��0.5
		{
			if (C.IsEmpty())
			{
				for (int i = 0; i < 5; i++)
				{
					string s1, s2;
					int c, t, r;
					cout << "������������Ϣ��" << endl << "�����������";
					cin >> s1;
					cout << "��������ţ�0-199����";
					cin >> c;
					cout << "����ŵ��ţ�0-19����";
					cin >> t;
					cout << "����������¼�ţ�0-7����";
					cin >> r;
					cout << "���뷽�򣺣�up or down����";
					cin >> s2;
					A[i] = Table(s1, c, t, r, s2);
					cout << endl;
				}
				C = Link_Table(A, 5);  //����I/O��
				system("pause");
				system("cls");
			}
			else
			{
				cout << "��������" << endl;
				system("cls");
			}
				
		}
	}
	
	

	return 0;
}